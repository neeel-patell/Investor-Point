package in.weareindian.quiknews;

import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import in.weareindian.quiknews.ui.blog.BlogFragment;
import in.weareindian.quiknews.ui.business.BusinessFragment;
import in.weareindian.quiknews.ui.defense.DefenseFragment;
import in.weareindian.quiknews.ui.home.HomeFragment;
import in.weareindian.quiknews.ui.lists.ListsFragment;
import in.weareindian.quiknews.ui.prime.PrimeFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class MainActivity extends AppCompatActivity {
    private ActionBarDrawerToggle mDrawerToggle;
    DrawerLayout drawerLayout;
    LinearLayout customToolbar;
    TextView tvHome, tvBusiness, tvDefense, tvPrime, tvLists, tvBlog;
    LinearLayout llMain;
    ImageView ivMenu;
    TextView tvTitle, tvMainTitle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Init();
        SetDrawer();
        getPermission();

        ivMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT))
                    drawerLayout.closeDrawers();
                else
                    drawerLayout.openDrawer(Gravity.LEFT);
            }
        });



        tvHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawers();
                replaceFragment(new HomeFragment());
            }
        });

        tvBusiness.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawers();
                replaceFragment(new BusinessFragment());
            }
        });

        tvDefense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawers();
                replaceFragment(new DefenseFragment());
            }
        });

        tvPrime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawers();
                replaceFragment(new PrimeFragment());
            }
        });

        tvLists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawers();
                replaceFragment(new ListsFragment());
            }
        });

        tvBlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawers();
                replaceFragment(new BlogFragment());
            }
        });


    }

    private void getPermission() {
    }

    private void SetDrawer() {
        mDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, null, R.string.openDrawer, R.string.closeDrawer) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                //CommonUtils.hideSoftKeyboard(MainActivity.this);
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }
        };

        drawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();
    }

    private void Init() {

        drawerLayout = findViewById(R.id.drawerLayout);
        customToolbar = findViewById(R.id.customToolbar);
        tvHome = findViewById(R.id.tvHome);
        tvBusiness = findViewById(R.id.tvBusiness);
        tvDefense = findViewById(R.id.tvDefense);
        tvPrime = findViewById(R.id.tvPrime);
        tvLists = findViewById(R.id.tvLists);
        tvBlog = findViewById(R.id.tvBlog);
        llMain = findViewById(R.id.llMain);
        ivMenu = findViewById(R.id.ivMenu);
        /*tvTitle = findViewById(R.id.tvTitle);
        tvMainTitle = findViewById(R.id.tvMainTitle);*/

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_business, R.id.navigation_defense, R.id.navigation_prime, R.id.navigation_lists)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        //NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);
    }

    public void replaceFragment(final Fragment fragment) {

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                String backStateName = fragment.getClass().getName();
                FragmentManager manager = getSupportFragmentManager();

                boolean fragmentPopped = manager.popBackStackImmediate(backStateName, 0);
                if (!fragmentPopped && manager.findFragmentByTag(backStateName) == null) {
                    FragmentTransaction ft = manager.beginTransaction();
                    ft.replace(R.id.nav_host_fragment, fragment, backStateName);
                    ft.addToBackStack(backStateName);
                    ft.commit();
                }
            }
        }, 200);
    }

}