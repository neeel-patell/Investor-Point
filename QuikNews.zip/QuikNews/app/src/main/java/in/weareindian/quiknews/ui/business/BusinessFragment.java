package in.weareindian.quiknews.ui.business;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ProgressBar;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import in.weareindian.quiknews.R;
import in.weareindian.quiknews.adapters.CategoryAdapter;
import in.weareindian.quiknews.api.ApiConstants;
import in.weareindian.quiknews.model.Category;
import in.weareindian.quiknews.model.MySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BusinessFragment extends Fragment {

    private BusinessViewModel mViewModel;
    View root;
    RecyclerView rvBusinessPost;
    LinearLayoutManager manager;
    ProgressBar progressBarBusiness;
    ArrayList<Category> list;
    CategoryAdapter adapter;
    Boolean isScrolling = false  ;
    int currentItems, totalItems, scrollOutItems;
    SwipeRefreshLayout swipeRefreshLayout;

    int limit = 0;
    String category = Integer.toString(0);
    String id, imageUrl, blog, time;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        mViewModel =
                ViewModelProviders.of(this).get(BusinessViewModel.class);
        root = inflater.inflate(R.layout.business_fragment, container, false);

        Init();
        GetDataFirstTime();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                //rvBusinessPost.setAdapter(null);
                rvBusinessPost.invalidate();
                GetDataFirstTime();
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        rvBusinessPost.addOnScrollListener(new RecyclerView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if(newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL)
                {
                    isScrolling = true;
                }
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                currentItems = manager.getChildCount();
                totalItems = manager.getItemCount();
                scrollOutItems = manager.findFirstVisibleItemPosition();

                if(isScrolling && (currentItems + scrollOutItems == totalItems - 1 ))
                {
                    isScrolling = false;
                    getMoreData();
                }
            }
        });

        mViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) { }});
        return root;
    }

    private void getMoreData() {
        progressBarBusiness.setVisibility(View.VISIBLE);
        limit = limit +20;

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                StringRequest request = new StringRequest(Request.Method.POST, ApiConstants.GET_LINKS_CATEGORY,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                try {
                                    JSONObject jsonObject = new JSONObject(response);
                                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                                    for(int i = 0; i<jsonArray.length(); i++)
                                    {
                                        JSONObject object = jsonArray.getJSONObject(i);
                                        imageUrl = object.getString("images");
                                        time = object.getString("time");
                                        Category temp = new Category(imageUrl, time);
                                        list.add(temp);
                                    }

                                    adapter.notifyDataSetChanged();
                                    progressBarBusiness.setVisibility(View.GONE);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }){

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("limit", Integer.toString(limit));
                        params.put("category", category);
                        return params;
                    }
                };
                MySingleton.getInstance(getContext()).addtoRequestQueue(request);

            }
        }, 1000);

    }

    private void GetDataFirstTime() {
        list = new ArrayList<>();
        StringRequest request = new StringRequest(Request.Method.POST,
                ApiConstants.GET_LINKS_CATEGORY,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("data");

                            for(int i = 0; i<jsonArray.length(); i++)
                            {
                                JSONObject object = jsonArray.getJSONObject(i);
                                imageUrl = object.getString("images");
                                time = object.getString("time");
                                Category temp = new Category(imageUrl, time);
                                list.add(temp);
                            }

                            adapter = new CategoryAdapter(getContext(), list);
                            rvBusinessPost.setAdapter(adapter);
                            rvBusinessPost.setLayoutManager(manager);
                            progressBarBusiness.setVisibility(View.GONE);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("limit", Integer.toString(limit));
                params.put("category", category);
                return params;
            }
        };
        MySingleton.getInstance(getContext()).addtoRequestQueue(request);
    }

    private void Init() {
        rvBusinessPost = root.findViewById(R.id.rvBusinessPost);
        manager = new LinearLayoutManager(getContext());
        progressBarBusiness = root.findViewById(R.id.progressBarBusiness);
        list = new ArrayList<>();
        swipeRefreshLayout = root.findViewById(R.id.swipeRefreshLayout);
    }

}